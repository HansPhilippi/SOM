﻿using System;
using System.Collections.Generic;
using System.Drawing;

public class ShapeCollection
{
    private List<Shape> contents;
    private int curIndex; // index for current shape

    public ShapeCollection()
        // each new shape collection is initiated with a test collection
    {
        contents = InitTestCollection();
        curIndex = 0;
    }

    public Shape CurrentShape()
    { return contents[curIndex]; }

    public void Next()
    { if (curIndex < contents.Count - 1) curIndex++; }

    public void Previous()
    { if (curIndex > 0) curIndex--; }

    private List<Shape> InitTestCollection()
    {
        // create a collection of example shapes

        List<Shape> testCollection = new List<Shape>();

        testCollection.Add(new Rectangle(200, 120, Color.Blue));
        // testCollection.Add(new Square(200, Color.Orange));
        testCollection.Add(new Triangle(60, 200, Color.Red));
        testCollection.Add(new Circle(100, Color.Yellow));
        testCollection.Add(new Triangle(250, 100, Color.Green));
        testCollection.Add(new Rectangle(120, 200, Color.Black));

        return testCollection;
    }
}